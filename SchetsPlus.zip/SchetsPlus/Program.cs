﻿using System;
using System.Windows.Forms;

namespace SketchEditor
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.Run(new MainWindow());
        }
    }
}
